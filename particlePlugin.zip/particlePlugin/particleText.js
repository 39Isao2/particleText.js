(function( $ ) {
  $.fn.particleText = function(aText) {

			// canvaアクセス
			var canvas = document.querySelector(".particle");

			// 描画機能有効に
			//var ctx = canvas.getContext("2d");
			var ctx = canvas.getContext("2d");

			// テキストの内容取得
			var copy = document.querySelector("#copy");

			// canvasサイズ取得
			var ww = canvas.width = window.innerWidth;
			var wh = canvas.height = window.innerHeight;


			// パーティクルclass初期化
			var particles = [],amount = 0,radius = 0;

			// 色の配列
			var colors = ["#fff"];
			//var colors = ["#468966","#FFF0A5", "#FFB03B","#B64926", "#8E2800"];

			// パーティクルclass
			function Particle(x,y){
			    this.x =  Math.random()*ww;
			    this.y =  Math.random()*wh;
			    this.dest = {
			        x : x,
			        y: y
			    };
			    // this.r =  Math.random()*5 + 2;
			    // 半径
			    var min = 1;
				var max = 3;
			    this.r =  Math.floor( Math.random() * (max + 1 - min) ) + min ;
			    this.vx = (Math.random()-0.5)*20;
			    this.vy = (Math.random()-0.5)*20;
			    this.accX = 0;
			    this.accY = 0;
			    // this.friction = Math.random()*0.05 + 0.94;
			    this.friction = Math.random()*0.05 + 0.94;
			    this.color = colors[Math.floor(Math.random()*6)];
			}


			// レンダリング
			Particle.prototype.render = function() {

			    // this.accX = (this.dest.x - this.x)/1000;
			    // this.accY = (this.dest.y - this.y)/1000;
			　　 this.accX = (this.dest.x - this.x)/1000;
			    this.accY = (this.dest.y - this.y)/1000;
			    this.vx += this.accX;
			    this.vy += this.accY;
			    this.vx *= this.friction;
			    this.vy *= this.friction;

			    this.x += this.vx;
			    this.y +=  this.vy;

			    ctx.fillStyle = this.color;
			    ctx.beginPath();
			    // ctx.arc(this.x, this.y, this.r, Math.PI * 2, false);
			    ctx.arc(this.x, this.y, this.r, Math.PI, false);
			    ctx.fill();


			    var distance = Math.sqrt( this.x*this.x + this.y*this.y );

			    if(distance<(radius*70)){ 
			        this.accX = this.x/100;
			        this.accY = this.y/100;
			        this.vx += this.accX;
			        this.vy += this.accY;
			    }

			}


			// シーン初期化
			function initScene(){

			    // キャンバス初期化
			    ww = canvas.width = window.innerWidth;
			    wh = canvas.height = window.innerHeight;
			    ctx.clearRect(0, 0, canvas.width, canvas.height);

			    // フォントとテキスト表示 中央揃え
			    ctx.font = "bold "+(ww/10)+"px sans-serif";
			    ctx.textAlign = "center";
			    // ctx.fillText(copy.value, ww/2, wh/2);
			    // ctx.fillText(copy.innerText, ww/2, wh/2);
			    ctx.fillText(aText, ww/2, wh/2);
			  


			    // 領域全部のImageDataオブジェクト取得
			    var data  = ctx.getImageData(0, 0, ww, wh).data;
			    ctx.clearRect(0, 0, canvas.width, canvas.height);
			    // 重なった際にscreenモードに
			    ctx.globalCompositeOperation = "screen";

			    particles = [];
			    // for(var i=0;i<ww;i+=Math.round(ww/150)){
			    //     for(var j=0;j<wh;j+=Math.round(ww/150)){
			    //         if(data[ ((i + j*ww)*4) + 3] > 150){
			    //             particles.push(new Particle(i,j));
			    //         }
			    //     }
			    // }
			    for(var i=0;i<ww;i+=Math.round(ww/300)){
			        for(var j=0;j<wh;j+=Math.round(ww/300)){
			            if(data[ ((i + j*ww)*4) + 3] > 150){
			                particles.push(new Particle(i,j));
			            }
			        }
			    }
			    amount = particles.length;

			}


			function render(a) {
			    requestAnimationFrame(render);
			    ctx.clearRect(0, 0, canvas.width, canvas.height);
			    for (var i = 0; i < amount; i++) {
			        particles[i].render();
			    }
			};

			// リサイズしたら再度描画
			window.addEventListener("resize", initScene);

			initScene();
			requestAnimationFrame(render);
			  		
	};
})(jQuery);